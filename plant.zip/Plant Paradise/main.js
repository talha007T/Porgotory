function updateTime(){
    const now = new Date();
    document.getElementById(`DateTime`).textContent = now.toLocaleString();
}

updateTime();
setInterval(updateTime, 1000)